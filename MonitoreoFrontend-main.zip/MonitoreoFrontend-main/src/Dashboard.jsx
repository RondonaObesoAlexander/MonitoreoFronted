import React, { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { HardDrive, Cpu, ShieldCheck, Wifi, Lock } from 'lucide-react';

const DashboardMockup = () => {
  const [data, setData] = useState([]);

  // Generador de datos falsos para el MOCKUP
  useEffect(() => {
    const mockData = [];
    let horaActual = new Date();
    
    for (let i = 15; i >= 0; i--) {
      const tiempo = new Date(horaActual.getTime() - i * 5 * 60000);
      mockData.push({
        fecha: tiempo.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        memoria_libre: Math.floor(Math.random() * (400 - 200 + 1) + 200), // Entre 200 y 400 MB
        disco_uso: Math.floor(Math.random() * (25 - 15 + 1) + 15),       // 15% a 25%
        trafico_red: Math.floor(Math.random() * (1000 - 100 + 1) + 100)  // 100 a 1000 kbps
      });
    }
    setData(mockData);
  }, []);

  return (
    <div className="h-screen bg-slate-50 text-slate-800 p-4 flex flex-col overflow-hidden font-sans">
      
      {/* HEADER COMPACTO CON BADGE DE AUTENTICACIÓN */}
      <header className="flex justify-between items-center mb-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Sistema Externo de Monitoreo</h1>
          <p className="text-sm text-slate-500">Host: Debian 13 | Docker Cluster (Passbolt & ChkMonitor)</p>
        </div>
        <div className="flex gap-4">
          <div className="px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 bg-slate-100 text-slate-600 border border-slate-200">
            <Lock size={14} /> ADMIN_JIM
          </div>
          <div className="px-4 py-1.5 rounded-full text-sm font-bold flex items-center gap-2 bg-emerald-100 text-emerald-700">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            SISTEMA ACTIVO
          </div>
        </div>
      </header>

      {/* TARJETAS DE SERVICIOS (Shrink-0 para no aplastarse) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4 shrink-0">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-100 text-blue-600 rounded-lg"><Cpu size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Última RAM Registrada</p>
            <h3 className="text-lg font-bold">245 MB Libre</h3>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-100 text-amber-600 rounded-lg"><HardDrive size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Passbolt Container</p>
            <h3 className="text-lg font-bold text-emerald-600">Activo (Port 8080)</h3>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-indigo-100 text-indigo-600 rounded-lg"><ShieldCheck size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">ChkMonitor Container</p>
            <h3 className="text-lg font-bold text-emerald-600">Activo (Port 8081)</h3>
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-100 text-emerald-600 rounded-lg"><Wifi size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Tráfico de Red</p>
            <h3 className="text-lg font-bold text-slate-800">Normal</h3>
          </div>
        </div>
      </div>

      {/* ÁREA DE GRÁFICAS (Flex-1 para ocupar el resto del espacio) */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 min-h-0">
        
        {/* GRÁFICA 1: RAM (Ocupa todo el ancho superior en pantallas grandes) */}
        <div className="md:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col min-h-0">
          <h2 className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Histórico de Memoria RAM Libre (MB)</h2>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 5, right: 20, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="fecha" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} domain={['dataMin - 50', 'dataMax + 50']} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="memoria_libre" stroke="#3b82f6" strokeWidth={3} dot={{ r: 3 }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* GRÁFICA 2: DISCO */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col min-h-0">
          <h2 className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Uso de Disco (%)</h2>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 5, right: 20, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="fecha" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} domain={[0, 100]} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Area type="step" dataKey="disco_uso" stroke="#8b5cf6" fill="#c4b5fd" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* GRÁFICA 3: RED */}
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col min-h-0">
          <h2 className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Tráfico de Red (kbps)</h2>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 5, right: 20, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="fecha" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} />
                <Tooltip contentStyle={{ borderRadius: '8px', fontSize: '12px' }} />
                <Line type="monotone" dataKey="trafico_red" stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>
    </div>
  );
};

export default DashboardMockup;