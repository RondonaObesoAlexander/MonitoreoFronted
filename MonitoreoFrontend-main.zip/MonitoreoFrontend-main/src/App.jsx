import React, { useState } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';

function App() {
  const [authToken, setAuthToken] = useState(null);

  const handleLogin = (token) => {
    setAuthToken(token);
  };

  const handleLogout = () => {
    setAuthToken(null);
  };

  return (
    <div className="min-h-screen bg-slate-50">
      {!authToken ? (
        <Login onLogin={handleLogin} />
      ) : (
        <Dashboard token={authToken} onLogout={handleLogout} />
      )}
    </div>
  );
}

export default App;