import React, { useState, useEffect } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { HardDrive, Cpu, ShieldCheck, Wifi, Lock, LogOut } from 'lucide-react';

const Dashboard = ({ token, onLogout }) => {
  const [data, setData] = useState([]);
  const [status, setStatus] = useState('CONECTANDO...');

  const fetchMetricas = async () => {
    try {
      // ATENCIÓN: Cambia 'localhost' por la IP de tu máquina virtual si el backend corre allá
      const response = await fetch('http://localhost:5000/api/metricas', {
        headers: { 'Authorization': `Basic ${token}` }
      });
      
      if (!response.ok) throw new Error('Error en API');
      
      const result = await response.json();
      
      // Formateamos los datos para Recharts (de viejo a nuevo)
      const formattedData = result.reverse().map(item => ({
        ...item,
        fecha: new Date(item.fecha).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        // Ajustamos la memoria para que se lea en MB (asumiendo que SNMP devuelve KB)
        memoria_libre: Math.round(item.memoria_libre / 1024)
      }));

      setData(formattedData);
      setStatus(formattedData.length > 0 ? 'ACTIVO' : 'SIN DATOS');

    } catch (error) {
      console.error("Error fetching data:", error);
      setStatus('ERROR DE CONEXIÓN');
    }
  };

  useEffect(() => {
    fetchMetricas();
    // Actualizar datos cada 10 segundos para la presentación en vivo
    const interval = setInterval(fetchMetricas, 10000);
    return () => clearInterval(interval);
  }, []);

  const ultimaMetrica = data.length > 0 ? data[data.length - 1] : { memoria_libre: 0, disco_disponible: 0, trafico_red: 0 };

  return (
    <div className="h-screen bg-slate-50 text-slate-800 p-4 flex flex-col overflow-hidden font-sans">
      {/* Header */}
      <header className="flex justify-between items-center mb-4 bg-white p-4 rounded-xl border border-slate-200 shadow-sm shrink-0">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Sistema Externo de Monitoreo</h1>
          <p className="text-sm text-slate-500">Host: Debian 13 | Docker Cluster</p>
        </div>
        <div className="flex gap-4">
          <div className="px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-2 bg-slate-100 text-slate-600 border border-slate-200">
            <Lock size={14} /> ADMIN_JIM
          </div>
          <div className={`px-4 py-1.5 rounded-full text-sm font-bold flex items-center gap-2 ${status === 'ACTIVO' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
            <div className={`w-2 h-2 rounded-full ${status === 'ACTIVO' ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`}></div>
            SISTEMA {status}
          </div>
          <button onClick={onLogout} className="p-2 text-slate-400 hover:text-red-500 transition-colors">
            <LogOut size={20} />
          </button>
        </div>
      </header>

      {/* Tarjetas Superiores */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4 shrink-0">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-blue-100 text-blue-600 rounded-lg"><Cpu size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Última RAM Registrada</p>
            <h3 className="text-lg font-bold">{ultimaMetrica.memoria_libre} MB Libre</h3>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-100 text-amber-600 rounded-lg"><HardDrive size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Passbolt Container</p>
            <h3 className={`text-lg font-bold ${status === 'ACTIVO' ? 'text-emerald-600' : 'text-red-600'}`}>{status === 'ACTIVO' ? 'Activo (Port 8080)' : 'Inactivo'}</h3>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-indigo-100 text-indigo-600 rounded-lg"><ShieldCheck size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">ChkMonitor Container</p>
            <h3 className={`text-lg font-bold ${status === 'ACTIVO' ? 'text-emerald-600' : 'text-red-600'}`}>{status === 'ACTIVO' ? 'Activo (Port 8081)' : 'Inactivo'}</h3>
          </div>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-100 text-emerald-600 rounded-lg"><Wifi size={24} /></div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase">Tráfico Reciente</p>
            <h3 className="text-lg font-bold text-slate-800">{ultimaMetrica.trafico_red} kbps</h3>
          </div>
        </div>
      </div>

      {/* Gráficas */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 min-h-0">
        <div className="md:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col min-h-0">
          <h2 className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Histórico de Memoria RAM Libre (MB)</h2>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 5, right: 20, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="fecha" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} domain={['dataMin - 100', 'dataMax + 100']} />
                <Tooltip />
                <Line type="monotone" dataKey="memoria_libre" stroke="#3b82f6" strokeWidth={3} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col min-h-0">
          <h2 className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Métrica de Disco Duro</h2>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data} margin={{ top: 5, right: 20, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="fecha" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} />
                <Tooltip />
                <Area type="step" dataKey="disco_disponible" stroke="#8b5cf6" fill="#c4b5fd" strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-4 flex flex-col min-h-0">
          <h2 className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wider">Tráfico de Red Entrante</h2>
          <div className="flex-1 w-full min-h-0">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 5, right: 20, bottom: 0, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                <XAxis dataKey="fecha" stroke="#94a3b8" fontSize={10} />
                <YAxis stroke="#94a3b8" fontSize={10} />
                <Tooltip />
                <Line type="monotone" dataKey="trafico_red" stroke="#10b981" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;